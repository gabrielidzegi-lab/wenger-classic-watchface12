# Wenger Classic — Galaxy Watch 6 Classic (47 mm)

This is a Wear OS Watch Face Format (WFF) source project. It is **not** a prebuilt APK. It targets WFF version 1 / Wear OS 4+ (API 33+), suitable for the Galaxy Watch 6 Classic.

## Build using only an Android phone (GitHub Actions)

1. Sign in to GitHub in your phone browser and create a new **private** repository.
2. Upload the contents of this project folder to the repository (not the outer ZIP folder). Make sure `.github/workflows/build.yml` is included. If the mobile upload page hides dot-folders, create `.github/workflows/build.yml` using GitHub's web editor.
3. Open the repository's **Actions** tab and enable workflows if prompted.
4. Select **Build Wenger Classic watch face** and tap **Run workflow** (or push to `main` to trigger it).
5. When the run finishes successfully, open it and download the artifact named `Wenger-Classic-Watch6-APK`. Extract it on your phone; it contains `app-debug.apk`.

## Install from the Android phone to the watch

1. On the watch, enable Developer options: Settings → About watch → Software information → tap **Software version** repeatedly until developer mode is enabled (menu wording can vary).
2. Open Settings → Developer options; enable **ADB debugging** and **Wireless debugging**.
3. Install a reputable Wear OS sideloading app on the phone, such as Wear Installer 2. Pair it using the pairing code and pairing port shown under Wireless debugging on the watch.
4. After pairing, use the watch's current wireless debugging IP address and connection port, choose **Custom APK**, select `app-debug.apk`, and install it.
5. On the watch, long-press the current face and choose the Wenger face from Add watch face.
6. Turn ADB and Wireless debugging off again when finished.

Phone and watch must be on the same Wi-Fi network. Only install APKs you built yourself or trust.

## Notes

- The workflow builds a debug APK in GitHub's cloud; no computer or Android Studio is needed.
- This project has not yet been built or validated by Android Studio's Watch Face Format validator. If the build or watch installation reports an error, share the exact error so the project can be corrected.
- The dial artwork is a Wenger-inspired recreation. The hands and day/date fields are driven by the watch clock/system data.
