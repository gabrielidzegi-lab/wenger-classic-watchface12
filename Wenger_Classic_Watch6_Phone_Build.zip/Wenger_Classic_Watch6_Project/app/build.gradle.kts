plugins { id("com.android.application") }

android {
    namespace = "com.example.wengerclassic"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.wengerclassic"
        minSdk = 33
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
